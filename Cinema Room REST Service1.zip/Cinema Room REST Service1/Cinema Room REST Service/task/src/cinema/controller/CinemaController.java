package cinema.controller;

import cinema.entity.MovieTheater;
import cinema.entity.Seat;
import cinema.entity.Ticket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
public class CinemaController {

    @Autowired
    MovieTheater movieTheater;

    @GetMapping("/seats")
    public MovieTheater seats() {
        return movieTheater;
    }

    @PostMapping("/purchase")
    public Ticket purchase (@RequestBody Seat purchaseSeat) {
        return movieTheater.ticketBooking(purchaseSeat);
    }

    @PostMapping("/return")
    public Map<String, Seat> returnTicket (@RequestBody Map<String, String> map) {
        return movieTheater.returnTicket(map.get("token"));
    }

    @PostMapping("/stats")
    public ResponseEntity<?> stats(@RequestParam(value = "password", required = false) String pass){
        if (pass == null || !pass.equals("super_secret")) {
            return new ResponseEntity<>(Map.of("error", "The password is wrong!"), HttpStatus.UNAUTHORIZED);
        } else  {
            return new ResponseEntity<>(Map.of("current_income", movieTheater.getIncome(),
                    "number_of_available_seats", movieTheater.getAvailableSeats().size(),
                    "number_of_purchased_tickets", movieTheater.getBookedSeats().size()), HttpStatus.OK);
        }
    }

}
