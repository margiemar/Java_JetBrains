package cinema.entity;

import cinema.exception_handling.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class MovieTheater {

    private int totalRows = 9;
    private int totalColumns = 9;
    private List<Seat> availableSeats = new ArrayList<>();
    @JsonIgnore
    private List<Seat> bookedSeats = new ArrayList<>();
    @JsonIgnore
    private int income = 0;

    {
        for (int i = 1; i <= totalRows; i++) {
            for (int j = 1; j <= totalColumns; j++) {
                Seat newSeat = new Seat(i, j);
                newSeat.setPrice(i <= 4 ? 10 : 8);
                newSeat.setUuid(String.valueOf(UUID.randomUUID()));
                availableSeats.add(newSeat);
            }
        }
    }

    public MovieTheater() {}

    public MovieTheater(int totalRows, int totalColumns) {
        this.totalRows = totalRows;
        this.totalColumns = totalColumns;
    }

    public int getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(int totalRows) {
        this.totalRows = totalRows;
    }

    public int getTotalColumns() {
        return totalColumns;
    }

    public void setTotalColumns(int totalColumns) {
        this.totalColumns = totalColumns;
    }

    public List<Seat> getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(List<Seat> availableSeats) {
        this.availableSeats = availableSeats;
    }

    public List<Seat> getBookedSeats() {
        return bookedSeats;
    }

    public void setBookedSeats(List<Seat> bookedSeats) {
        this.bookedSeats = bookedSeats;
    }

    public int getIncome() {
        return income;
    }

    public void setIncome(int income) {
        this.income = income;
    }

    public Ticket ticketBooking(Seat purchaseSeat) {

        for (Seat tmpSeat : availableSeats) {
            if (purchaseSeat.equals(tmpSeat)) {
                availableSeats.remove(tmpSeat);
                bookedSeats.add(tmpSeat);
                income += tmpSeat.getPrice();
                return new Ticket(tmpSeat);
            } else if (bookedSeats.contains(purchaseSeat)){
                throw new SeatIsTakenException("The ticket has been already purchased!");
            } else if (purchaseSeat.getRow() < 1 ||
                    purchaseSeat.getRow() > 9 ||
                    purchaseSeat.getColumn() < 1 ||
                    purchaseSeat.getColumn() > 9) {
                throw new OutOfBoundsException("The number of a row or a column is out of bounds!");
            }
        }
        return new Ticket();
    }

    public Map<String, Seat> returnTicket (String uuid) {

        Seat bookedSeat = null;
        if (!bookedSeats.isEmpty()) {
            for (Seat seat : bookedSeats) {
                if (uuid.equals(seat.getUuid())) {
                    bookedSeat = seat;
                }
            }
        }
        if (bookedSeat != null) {
            bookedSeats.remove(bookedSeat);
            availableSeats.add(bookedSeat);
            income -= bookedSeat.getPrice();
        } else {throw new WrongTokenException();}

         return Map.of("returned_ticket", bookedSeat);
    }
}
