package cinema.entity;

import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class Ticket {
    String token;
    Seat ticket;

    public Ticket() {
    }

    public Ticket(Seat seat) {
        this.token = seat.getUuid();
        this.ticket = seat;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Seat getTicket() {
        return ticket;
    }

    public void setTicket(Seat ticket) {
        this.ticket = ticket;
    }
}
