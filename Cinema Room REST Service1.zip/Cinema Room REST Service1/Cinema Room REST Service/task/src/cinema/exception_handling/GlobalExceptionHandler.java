package cinema.exception_handling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler
    public ResponseEntity<PurchaseErr> handleException (SeatIsTakenException e) {

        PurchaseErr purchaseErr = new PurchaseErr();
        purchaseErr.setError(e.getMessage());
        return new ResponseEntity<>(purchaseErr, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler
    public ResponseEntity<PurchaseErr> handleException (OutOfBoundsException e) {

        PurchaseErr purchaseErr = new PurchaseErr();
        purchaseErr.setError(e.getMessage());
        return new ResponseEntity<>(purchaseErr, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler
    public ResponseEntity<PurchaseErr> handleException (Exception e) {

        PurchaseErr purchaseErr = new PurchaseErr();
        purchaseErr.setError(e.getMessage());
        return new ResponseEntity<>(purchaseErr, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(WrongTokenException.class)
    public ResponseEntity<Map<String, String>> handleException() {
        return new ResponseEntity<>(Map.of("error", "Wrong token!"),HttpStatus.BAD_REQUEST);
    }

}
