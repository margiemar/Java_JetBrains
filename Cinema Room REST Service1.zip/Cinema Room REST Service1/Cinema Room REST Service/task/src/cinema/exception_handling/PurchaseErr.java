package cinema.exception_handling;

public class PurchaseErr {

    private String error;

    public PurchaseErr() {
    }

    public PurchaseErr(String info) {
        this.error = info;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
