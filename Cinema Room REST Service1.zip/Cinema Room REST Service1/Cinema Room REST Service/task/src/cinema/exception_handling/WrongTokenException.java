package cinema.exception_handling;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus
public class WrongTokenException extends RuntimeException{
}
