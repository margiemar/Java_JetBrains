http://localhost:28857/

Сервис позволяет:

1) вывести информацию о свободных местах в кинозале по ссылке
/seats (метод GET)

Вывод в формате
{
    "total_rows": 9,
    "total_columns": 9,
    "available_seats": [
        {
            "row": 1,
            "column": 1,
            "price": 10
        },
		...

2) купить билет

/purchase (метод POST)
BODY
        {
            "row": 1,
            "column": 2,
        }

Возвращает информацию о купленном месте
{
    "token": "fd0e5492-7898-4482-9b1f-340512b172d7",
    "ticket": {
        "row": 1,
        "column": 2,
        "price": 10
    }
}

3) вернтуть билет
/return (метод POST)

BODY
        {
            "token": "fd0e5492-7898-4482-9b1f-340512b172d7"
        }

Bозвращает
{
    "returned_ticket": {
        "row": 1,
        "column": 2,
        "price": 10
    }
}

4) получить статистику
/stats (метод POST) только при наличии параметров "password" со значением "super_secret".

Возвращает
{
    "number_of_available_seats": 81,
    "current_income": 0,
    "number_of_purchased_tickets": 0
}

или
{
    "error": "The password is wrong!"
}
С кодом 401