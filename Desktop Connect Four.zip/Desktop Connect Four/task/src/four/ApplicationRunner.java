package four;

public class ApplicationRunner {
    public static void main(String[] args) {
        new ConnectFour();
    }
}