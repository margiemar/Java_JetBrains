package four;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class ConnectFour extends JFrame {



    List<CellInfo> buttonInfoList = new ArrayList<>();   // for fill the board
    JButton[][] buttonsBoard = new JButton[6][7];        // JButton.getText = ButtonA6
    int index = 0;                                       // Index of button in cellList
    int xIndicator = 0;                                  // Indicator of "X" in cell

    public ConnectFour() {
        super("Connect 4");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);
        setLayout( new BorderLayout());
        setVisible(true);

        JPanel gridPanel = new JPanel();
        gridPanel.setSize(500,500);
        gridPanel.setLayout(new GridLayout(6, 7, 0, 0));
        add(gridPanel, BorderLayout.CENTER);

        //Adding a buttons on buttonsBoard
        for (int i = 6; i >= 1; i--) {
            for (char c = 'A'; c <= 'G'; c++) {

                // filling by names ButtonA6 whith empty text
                String name = "Button" + c + i;
                JButton cellButton = new JButton(" ");
                cellButton.setBackground(Color.lightGray);
                cellButton.setName(name);

                //Buttons info list
                CellInfo cellInfo = new CellInfo(cellButton, name);
                buttonInfoList.add(cellInfo);

                //Click action
                cellButton.addActionListener(e -> {

                    OUTER: for (CellInfo info : buttonInfoList) {
                        if (info.getName().equals(cellButton.getName())) {
                            int J = info.j;
                            for (int I = 5; I >= 0; I--) {
                                if (buttonsBoard[I][J].getText().equals(" ")) {
                                    String XO = null;
                                    if (xIndicator == 0) {
                                        XO = "X";
                                        xIndicator = 1;
                                    } else {
                                        XO = "O";
                                        xIndicator = 0;
                                    }
                                    buttonsBoard[I][J].setText(XO);
                                    Winner.check(buttonsBoard, buttonInfoList);
                                    break OUTER;
                                }
                            }
                        }
                    }
                });

                gridPanel.add(cellButton);
            }

        }

        JButton reset = new JButton("Reset");
        reset.setName("ButtonReset");
        reset.addActionListener(e -> {
                  for (CellInfo c : buttonInfoList) {
                      c.getButton().setEnabled(true);
                      c.getButton().setText(" ");
                      c.getButton().setBackground(Color.lightGray);
                      xIndicator = 0;
                  }
                });


        add(reset,BorderLayout.SOUTH);

        //Converting buttonInfoList to buttonsBoard
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                buttonsBoard[i][j] = buttonInfoList.get(index).getButton();
                buttonInfoList.get(index).setI(i);
                buttonInfoList.get(index).setJ(j);
                index++;
            }
        }
    }

}