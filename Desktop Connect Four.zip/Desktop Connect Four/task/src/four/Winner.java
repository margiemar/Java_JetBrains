package four;

import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Winner {

    public static void check(JButton[][] b, List<CellInfo> buttonInfoList) {


        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                // horizontal
                if ( j < 4 && !" ".equals(b[i][j].getText()) &&
                        b[i][j].getText().equals(b[i][j + 1].getText()) &&
                        b[i][j].getText().equals(b[i][j + 2].getText()) &&
                        b[i][j].getText().equals(b[i][j + 3].getText())) {
                    gameOver(new JButton[]{b[i][j], b[i][j + 1], b[i][j + 2], b[i][j + 3]}, buttonInfoList);
                    // vertical
                } else if (i < 3 && !" ".equals(b[i][j].getText()) &&
                        b[i][j].getText().equals(b[i + 1][j].getText()) &&
                        b[i][j].getText().equals(b[i + 2][j].getText()) &&
                        b[i][j].getText().equals(b[i + 3][j].getText())) {
                    gameOver(new JButton[]{b[i][j], b[i + 1][j], b[i + 2][j], b[i + 3][j]}, buttonInfoList);
                    // left diagonal
                } else if (i < 3 && j < 4 && !" ".equals(b[i][j].getText()) &&
                        b[i][j].getText().equals(b[i + 1][j + 1].getText()) &&
                        b[i][j].getText().equals(b[i + 2][j + 2].getText()) &&
                        b[i][j].getText().equals(b[i + 3][j + 3].getText())) {
                    gameOver(new JButton[]{b[i][j], b[i + 1][j + 1], b[i + 2][j + 2], b[i + 3][j + 3]}, buttonInfoList);
                    // right diagonal
                } else if (j > 2 && i < 3 && !" ".equals(b[i][j].getText()) &&
                        b[i][j].getText().equals(b[i + 1][j - 1].getText()) &&
                        b[i][j].getText().equals(b[i + 2][j - 2].getText()) &&
                        b[i][j].getText().equals(b[i + 3][j - 3].getText())) {
                    System.out.println("CORRECT");
                    gameOver(new JButton[]{b[i][j], b[i + 1][j - 1], b[i + 2][j - 2], b[i + 3][j - 3]}, buttonInfoList);
                }
            }
        }
    }


    public static void gameOver(JButton [] win, List<CellInfo> buttonInfoList) {
        Arrays.stream(win).forEach(jb -> jb.setBackground(Color.magenta));
        buttonInfoList.stream().forEach(cell -> cell.getButton().setEnabled(false));
    }
}
